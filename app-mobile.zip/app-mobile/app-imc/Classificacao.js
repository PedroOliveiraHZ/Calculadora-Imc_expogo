export default function getClassification(imc) {
    let classificacao = '';
    if(imc <= 18.5) {
      classificacao = 'Baixo peso';
    }
    if(imc > 18.5 && imc < 24.9) {
      classificacao = 'eutrofia (peso adequado)';
    }
    if(imc > 24.9 && imc < 29.9) {
      classificacao = 'Sobrepeso';
    }
    if(imc > 25.0&& imc < 29.9) {
      classificacao = 'Obesidade grau 1';
    }
    if(imc > 30.0 && imc < 34.9) {
      classificacao = 'Obesidade grau 2';
    }
    if(imc >= 40) {
      classificacao = 'Obesidade grave';
    }
  
    return classificacao;
  }